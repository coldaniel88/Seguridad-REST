﻿using System;
using System.Collections.Generic;

namespace TallerApi.DataAccess.Models;

public partial class Email
{
    public int IdEmail { get; set; }

    public string Email1 { get; set; } = null!;
}
