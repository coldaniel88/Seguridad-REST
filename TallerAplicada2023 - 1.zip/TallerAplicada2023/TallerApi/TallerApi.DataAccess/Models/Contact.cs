﻿using System;
using System.Collections.Generic;

namespace TallerApi.DataAccess.Models;

public partial class Contact
{
    public int IdEmail { get; set; }

    public int IdTelephone { get; set; }
}
